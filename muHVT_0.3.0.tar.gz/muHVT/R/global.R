#' @import utils
#' 

utils::globalVariables(c(".","k","Segment.Level","Quant.Error","noOfCellsBelowQuantizationError","noOfCells","index"))