#' @import utils
#' 

utils::globalVariables(c(".","k","Segment.Level","Segment.Child","Quant.Error",
                         "noOfCellsBelowQuantizationError","noOfCells","index",
                         "Segment.Parent","cluster","child","value"))